package com.project;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Pair {

	private double latitude;
	private double longitude;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "result{latitude :" + this.latitude + ", longitude :" + this.longitude + "}";
	}
}
