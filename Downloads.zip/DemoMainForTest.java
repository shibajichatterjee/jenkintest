package com.project;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;

public class DemoMainForTest {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Pair pr = new Pair();
		String latVal = "";
		String longVal = "";
		List<Pair> trgLoctnList = new ArrayList<>();
		List<Pair> finalList = new ArrayList<>();

		pr = LocationTrackUtil.getLocationFromPostalCode("612 ");

		// System.out.println("Derived Latitude:" + pr.getLatitude() + ",Longitude:" +
		// pr.getLongitude());

		try {
			CSVParser csvParser = LocationTrackUtil.getCsvFile();

			for (CSVRecord csvRecord : csvParser) {
				Pair p = new Pair();
				latVal = csvRecord.get(8);
				longVal = csvRecord.get(9);
				if (StringUtils.isNotEmpty(latVal) && StringUtils.isNotEmpty(longVal)) {
					p.setLatitude(Double.parseDouble(latVal));
					p.setLongitude(Double.parseDouble(longVal));
				}
				trgLoctnList.add(p);
			}

			// System.out.println(trgLoctnList);

			finalList = LocationTrackUtil.getNearestLocations(pr, trgLoctnList);
			// System.out.println(finalList);
		} catch (IOException | NumberFormatException e) {
			System.out.println(e.getMessage());
		}

	}
}
