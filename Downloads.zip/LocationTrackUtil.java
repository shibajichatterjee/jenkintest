package com.project;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;

public class LocationTrackUtil {

	private LocationTrackUtil() {
	}

	static double deg2rad(double deg) {
		return (deg * Math.PI / 180.0);
	}

	static double rad2deg(double rad) {
		return (rad * 180.0 / Math.PI);
	}

	static double distance(double lat1, double lon1, double lat2, double lon2) {
		// haversine great circle distance approximation, returns meters
		double theta = lon1 - lon2;
		double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2))
				+ Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
		dist = Math.acos(dist);
		dist = rad2deg(dist);
		// dist = dist * 60; // 60 nautical miles per degree of seperation
		dist = dist * 1852; // 1852 meters per nautical mile
		// dist = dist * 60 * 1.1515;
		// dist = dist * 1.609344;
		return (dist);
	}

	public static CSVParser getCsvFile() throws IOException {

		File rFile = new File(LocationTrackUtil.class.getClassLoader().getResource("USZIPCodes202201.csv").getFile());
		return CSVParser.parse(rFile, Charset.defaultCharset(), CSVFormat.DEFAULT.withFirstRecordAsHeader());
	}

	@SuppressWarnings("finally")
	public static Pair getLocationFromPostalCode(String postalCode) {

		Pair p = new Pair();
		String latVal = "";
		String longVal = "";

		if (postalCode == null)
			return p;

		postalCode = postalCode.trim().replaceFirst("^0+(?!$)", "").replaceAll("\\s", "");
		if ("".equals(postalCode))
			return p;

		try {

			CSVParser csvParser = getCsvFile();

			for (CSVRecord csvRecord : csvParser) {

				if (postalCode
						.equalsIgnoreCase(csvRecord.get(0).trim().replaceFirst("^0+(?!$)", "").replaceAll("\\s", ""))) {

					latVal = csvRecord.get(8);
					longVal = csvRecord.get(9);
					if (StringUtils.isNotEmpty(latVal) && StringUtils.isNotEmpty(longVal)) {
						p.setLatitude(Double.parseDouble(latVal));
						p.setLongitude(Double.parseDouble(longVal));
					}
					break;
				}

			}
		} catch (IOException | NumberFormatException e) {
			System.out.println(e.getMessage()); // don't do any restricted activities, only log/show messaging
		} finally {
			return p;
		}
	}

	@SuppressWarnings("finally")
	public static List<Pair> getNearestLocations(Pair sourceLocation, List<Pair> listOfTargetLocations) {

		List<PairDistance> tempList = new ArrayList<>();
		List<Pair> finalList = new ArrayList<>();
		try {

			for (Pair p : listOfTargetLocations) {
				PairDistance pd = new PairDistance();
				pd.setLatitude(p.getLatitude());
				pd.setLongitude(p.getLongitude());
				pd.setDistance(distance(sourceLocation.getLatitude(), sourceLocation.getLongitude(), p.getLatitude(),
						p.getLongitude()));
				tempList.add(pd);
			}

			TreeSet<PairDistance> sortedList = tempList.stream().collect(Collectors
					.toCollection(() -> new TreeSet<>(Comparator.comparingDouble(PairDistance::getDistance))));

			// List<PairDistance> sortedList =
			// tempList.stream()//.filter(distinctByKey(PairDistance::getDistance))
			// .sorted(Comparator.comparingDouble(PairDistance::getDistance)).collect(Collectors.toList());

			//sortedList.stream().limit(10).forEachOrdered(System.out::println);

			for (PairDistance p : sortedList) {
				Pair pr = new Pair();
				pr.setLatitude(p.getLatitude());
				pr.setLongitude(p.getLongitude());
				finalList.add(pr);
			}
			
			//finalList.forEach(System.out::println);
		} catch (NumberFormatException e) {
			System.out.println(e.getMessage()); // don't do any restricted activities, only log/show messaging
		} finally {
			return finalList;
		}

	}

}
